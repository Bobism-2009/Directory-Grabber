Directory Grabber
================

A simple and powerful tool to browse and manage files and directories.

Features:
- Select and view file directories
- Search files and folders
- Filter by file type
- Sort by name, size, or date
- Copy file paths
- Dark mode support
- File preview
- No installation required

How to Use:
1. Double-click DirectoryGrabber.exe to run
2. Click "Select File" to choose a file
3. Use the search bar to find files
4. Use filters to show only files or folders
5. Click "Copy Path" to copy the selected file's path
6. Toggle dark mode with the "Toggle Dark Mode" button

Requirements:
- Windows 7 or newer
- No installation needed
- No Python needed
- No other dependencies

Note: This is a portable application. You can move it anywhere and it will work! 